# paperless
dynamic split payments mostly to accomodate the owanbe culture
